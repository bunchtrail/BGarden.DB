﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class v234 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "EastBound",
                table: "MapOptions",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "NorthBound",
                table: "MapOptions",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SouthBound",
                table: "MapOptions",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "WestBound",
                table: "MapOptions",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Zoom",
                table: "MapOptions",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "PopupContent",
                table: "MapMarkers",
                type: "text",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EastBound",
                table: "MapOptions");

            migrationBuilder.DropColumn(
                name: "NorthBound",
                table: "MapOptions");

            migrationBuilder.DropColumn(
                name: "SouthBound",
                table: "MapOptions");

            migrationBuilder.DropColumn(
                name: "WestBound",
                table: "MapOptions");

            migrationBuilder.DropColumn(
                name: "Zoom",
                table: "MapOptions");

            migrationBuilder.DropColumn(
                name: "PopupContent",
                table: "MapMarkers");
        }
    }
}
