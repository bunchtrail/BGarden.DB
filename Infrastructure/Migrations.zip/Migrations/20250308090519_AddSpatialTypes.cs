﻿using Microsoft.EntityFrameworkCore.Migrations;
using NetTopologySuite.Geometries;

#nullable disable

namespace Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddSpatialTypes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("Npgsql:PostgresExtension:postgis", ",,");

            migrationBuilder.AddColumn<Point>(
                name: "Location",
                table: "Specimens",
                type: "geometry(Point,4326)",
                nullable: true);

            migrationBuilder.AddColumn<Polygon>(
                name: "Boundary",
                table: "Regions",
                type: "geometry(Polygon,4326)",
                nullable: true);

            migrationBuilder.AddColumn<Point>(
                name: "Location",
                table: "Regions",
                type: "geometry(Point,4326)",
                nullable: true);

            migrationBuilder.AddColumn<Point>(
                name: "Location",
                table: "MapMarkers",
                type: "geometry(Point,4326)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Specimen_Location_Spatial",
                table: "Specimens",
                column: "Location");

            migrationBuilder.CreateIndex(
                name: "IX_MapMarker_Location_Spatial",
                table: "MapMarkers",
                column: "Location");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Specimen_Location_Spatial",
                table: "Specimens");

            migrationBuilder.DropIndex(
                name: "IX_MapMarker_Location_Spatial",
                table: "MapMarkers");

            migrationBuilder.DropColumn(
                name: "Location",
                table: "Specimens");

            migrationBuilder.DropColumn(
                name: "Boundary",
                table: "Regions");

            migrationBuilder.DropColumn(
                name: "Location",
                table: "Regions");

            migrationBuilder.DropColumn(
                name: "Location",
                table: "MapMarkers");

            migrationBuilder.AlterDatabase()
                .OldAnnotation("Npgsql:PostgresExtension:postgis", ",,");
        }
    }
}
