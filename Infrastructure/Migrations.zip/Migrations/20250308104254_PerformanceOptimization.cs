﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PerformanceOptimization : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Добавляем индекс для часто используемого поля CreatedAt в таблице Specimens
            migrationBuilder.CreateIndex(
                name: "IX_Specimens_CreatedAt",
                table: "Specimens",
                column: "CreatedAt");

            // Добавляем составной индекс для поиска образцов по семейству и экспозиции
            migrationBuilder.CreateIndex(
                name: "IX_Specimens_FamilyId_ExpositionId",
                table: "Specimens",
                columns: new[] { "FamilyId", "ExpositionId" });

            // Индекс для поиска по SectorType в Specimens
            migrationBuilder.CreateIndex(
                name: "IX_Specimens_SectorType",
                table: "Specimens",
                column: "SectorType");

            // Индекс для поиска по русскому и латинскому названиям (хотя для полнотекстового поиска лучше использовать GIN индексы)
            migrationBuilder.CreateIndex(
                name: "IX_Specimens_LatinName",
                table: "Specimens",
                column: "LatinName");

            migrationBuilder.CreateIndex(
                name: "IX_Specimens_RussianName",
                table: "Specimens",
                column: "RussianName");

            // Добавляем индекс для последних событий аутентификации
            migrationBuilder.CreateIndex(
                name: "IX_AuthLogs_UserId_Timestamp",
                table: "AuthLogs",
                columns: new[] { "UserId", "Timestamp" });

            // Индекс для оптимизации запросов для регионов по типу сектора
            migrationBuilder.CreateIndex(
                name: "IX_Regions_SectorType",
                table: "Regions",
                column: "SectorType");

            // Индекс для поиска пользователей по роли
            migrationBuilder.CreateIndex(
                name: "IX_Users_Role",
                table: "Users",
                column: "Role");

            // Индекс для поиска пользователей по email
            migrationBuilder.CreateIndex(
                name: "IX_Users_Email",
                table: "Users",
                column: "Email",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Удаление созданных индексов
            migrationBuilder.DropIndex(
                name: "IX_Specimens_CreatedAt",
                table: "Specimens");

            migrationBuilder.DropIndex(
                name: "IX_Specimens_FamilyId_ExpositionId",
                table: "Specimens");

            migrationBuilder.DropIndex(
                name: "IX_Specimens_SectorType",
                table: "Specimens");

            migrationBuilder.DropIndex(
                name: "IX_Specimens_LatinName",
                table: "Specimens");

            migrationBuilder.DropIndex(
                name: "IX_Specimens_RussianName",
                table: "Specimens");

            migrationBuilder.DropIndex(
                name: "IX_AuthLogs_UserId_Timestamp",
                table: "AuthLogs");

            migrationBuilder.DropIndex(
                name: "IX_Regions_SectorType",
                table: "Regions");

            migrationBuilder.DropIndex(
                name: "IX_Users_Role",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_Email",
                table: "Users");
        }
    }
}
